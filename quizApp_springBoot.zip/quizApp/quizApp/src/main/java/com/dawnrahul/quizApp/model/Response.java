package com.dawnrahul.quizApp.model;

import java.util.List;

import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
//import lombok.RequiredArgsConstructor;

@Component
@Entity
//@RequiredArgsConstructor
public class Response {
	@Id
	Integer id;
	String response;
	
	
	public Response() {
		
	}
	
	public Response(Integer id, String response) {
		super();
		this.id = id;
		this.response = response;
	}
	
	
	//Getters and Setters
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	
	
}
