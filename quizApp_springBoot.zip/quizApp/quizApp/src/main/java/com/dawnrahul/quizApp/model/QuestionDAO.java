package com.dawnrahul.quizApp.model;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;



@Repository
public interface QuestionDAO extends JpaRepository<Question, Integer> {
	
	List<Question> findQuestionsByCategory(String category);
	
	
	Question findQuestionById(Integer id);

	@Query(value = "select * from question q where q.category=:category Order By Random() Limit :numQ" , nativeQuery=true)
	List<Question> findRandomQuestionsByCategory(String category, Integer numQ);
}
