package com.dawnrahul.quizApp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dawnrahul.quizApp.model.Question;
import com.dawnrahul.quizApp.model.QuestionDAO;
import com.dawnrahul.quizApp.model.QuestionWrapper;
import com.dawnrahul.quizApp.model.Quiz;
import com.dawnrahul.quizApp.model.QuizDao;
import com.dawnrahul.quizApp.model.Response;

@Service
public class QuizService {
	
	@Autowired
	QuizDao quizDao;
	
	@Autowired
	Quiz quiz;
	
	@Autowired
	QuestionDAO questionDao;

	public String createQuiz(String category, Integer numQ, String title) {
		quiz.setTitle(title);
		// id will automatically be set
		List<Question> questions = questionDao.findRandomQuestionsByCategory(category, numQ);
		quiz.setQuestions(questions);
		quizDao.save(quiz);
		
		
		return "Created";
	}

	public List<QuestionWrapper> getQuizQuestions(Integer id) {
		
		//it will get the quiz with the matching id - eg- Quiz - Java1 with id = 1
		Optional<Quiz> quiz = quizDao.findById(id);
		
		//now we'll get hold on the questions from that particular quiz - Java1
		List<Question> questionsFromQuiz = quiz.get().getQuestions();
		
		//now we will get only those field which is required by the QuestionWrapper entity
		List<QuestionWrapper> questionsForUser = new ArrayList<>();
		
		for(Question q : questionsFromQuiz) {
			QuestionWrapper qw = new QuestionWrapper(q.getId(), q.getOption1(), q.getOption2(), q.getOption3(), q.getOption4(), q.getQuestionTitle());
			questionsForUser.add(qw);
		}
		
		return questionsForUser;
		
	}

	public Integer getQuizResult(Integer id, List<Response> responses) {
		
		Quiz quiz = quizDao.findById(id).get();       //using <Optional> is recommended, because it checks for null

		List<Question> questions = quiz.getQuestions();
		
		int right = 0;
		int i = 0;
		for(Question q : questions) {
			if(q.getRightAnswer().equals(responses.get(i).getResponse())) {
				right++;
			}
			i++;
		}
		
		return right;
	}
}
