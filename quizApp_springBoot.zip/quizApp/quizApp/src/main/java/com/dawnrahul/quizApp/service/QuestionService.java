package com.dawnrahul.quizApp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.dawnrahul.quizApp.model.Question;
import com.dawnrahul.quizApp.model.QuestionDAO;

@Service
public class QuestionService {
	
	@Autowired
	QuestionDAO questionDao;

	//to get all the questions in the table
	public ResponseEntity<List<Question>> findAllQuestions(){
		try {
			return new ResponseEntity<>(questionDao.findAll(), HttpStatus.OK);
		}catch(Exception e) {
			//returning Empty arrayList and Http Response status code, if there is any exception
			e.printStackTrace();
			return new ResponseEntity<>(new ArrayList<>(), HttpStatus.NOT_FOUND);
		}
			
	}
	
	//to find the question by category
	public ResponseEntity<List<Question>> findQuestionsByCategory(String category){
		try {
			return new ResponseEntity<>(questionDao.findQuestionsByCategory(category), HttpStatus.OK);
		}catch(Exception e) {
			//returning Empty arrayList and Http Response status code, if there is any exception
			e.printStackTrace();
			return new ResponseEntity<>(new ArrayList<>(), HttpStatus.NOT_FOUND);
		}
	}
	
	//Insert question where id will be auto generated
	public ResponseEntity<String> addQuestion(Question question) {
		
		try {
			questionDao.save(question);
			return new ResponseEntity<>("Success", HttpStatus.ACCEPTED);
		}catch(Exception e){
			e.printStackTrace();
			return new ResponseEntity<>("Row insertion failed", HttpStatus.NOT_MODIFIED);
		}

	}
	
    //Delete
	public ResponseEntity<String> removeQuestionById(Integer id){
		try {
			questionDao.deleteById(id);
			return new ResponseEntity<>("Removed row with id=" + id, HttpStatus.ACCEPTED);
		}catch(Exception e){
			e.printStackTrace();
			return new ResponseEntity<>("Row removal failed", HttpStatus.NOT_MODIFIED);
		}
	}
	
	//Update category
	public ResponseEntity<String> updateQuestionById(Integer id, String category){
		try {
			Question q = questionDao.findQuestionById(id);
			q.setCategory(category);
			questionDao.save(q);
			return new ResponseEntity<>("Updated category of id=" + id, HttpStatus.ACCEPTED);
		}catch(Exception e){
			e.printStackTrace();
			return new ResponseEntity<>("Category update failed", HttpStatus.NOT_MODIFIED);
		}
	}
	
	
}
